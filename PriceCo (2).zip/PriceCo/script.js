

function navigateToPage() {
    var select = document.getElementById("pageSelect");
    var selectedOption = select.options[select.selectedIndex];
    var pageUrl = selectedOption.value;
    
    if (pageUrl) {
        window.location.href = pageUrl;
    }
}